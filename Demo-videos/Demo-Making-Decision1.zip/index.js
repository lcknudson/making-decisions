let jonSnowAttack = 25
let jamieLannisterAttack = 35

let jonSnowHealth = 100
let jonSnowDefense = 10

// if(jonSnowAttack > jamieLannisterAttack){
//   console.log('Jon Snow has a greater attack power than Jamie Lannister')
// } else if(jamieLannisterAttack > jonSnowAttack) {
//   console.log("Jamie Lannister has a greater attack power than Jon Snow")
// } else {
//   console.log('Jon and Jamie are the samie')
// }


//Jamie attack Jon (Lorin's try)
// let jonRemaingHealth = jonSnowHealth - jamieLannisterAttack + jonSnowDefense
// if(jonRemaingHealth > 0){
//   console.log('Jon survived the attack') 
// } else console.log('Jon Died')

//Instructors demo (Except halthKit variable)
// if(jonSnowHealth <= jamieLannisterAttack - jonSnowDefense){
//   console.log("See ya Jon")
// } else {
//   jonSnowHealth -= (jamieLannisterAttack - jonSnowDefense)
//   console.log(`Jon has ${jonSnowHealth} health`)
// }

// let healthKit = 50
// if(jonSnowHealth + healthKit >= 100){
//   jonSnowHealth = 100
//   console.log(`Jon is back to full health!`)
// } else {
//   jonSnowHealth += healthKit
//   console.log(`Jon's health has been increased to ${jonSnowHealth} health`)
// }

//Lorin's Attempt
// let coinToss = `Heads`
// if(coinToss !== `Heads`){
//   console.log(`Jon runs away, fight over`)
// } else {
//   console.log(`Jamie tries to behead Jon`)
// }
//   console.log(`Cointoss ${coinToss}`)

//Instructor's version
let coinLandsHeads = false

if(coinLandsHeads === true){
  console.log(`The fight continues!`)
} else {
  console.log(`Jon is allowed to run away`)
}